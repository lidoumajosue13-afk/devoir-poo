"""Starter pour le TP noté : Gestion d'étudiants en POO.

Consignes :
- compléter les fonctions demandées dans l'énoncé,
- ne pas modifier la logique de la classe `Etudiant`,
- utiliser la liste `etudiants` et un menu console.

Astuce : si vous importez `Etudiant` depuis `cours1105.py`, pensez que ce fichier exécute du code en bas de page.
"""


def afficher_menu():
    pass


def choisir_index(etudiants):
    pass


def lister_etudiants(etudiants):
    pass


def saluer_etudiant(etudiants):
    pass


def modifier_age(etudiants):
    pass


def ajouter_etudiant(etudiants):
    pass


def supprimer_etudiant(etudiants):
    pass


def afficher_compteur():
    pass


def main():
    # TODO : importer Etudiant depuis cours1105.py ou recopier la classe dans un autre fichier de travail.
    # TODO : créer les trois étudiants de départ.
    # TODO : stocker ces objets dans une liste appelée etudiants.
    # TODO : exécuter la boucle du menu.
    pass


if __name__ == "__main__":
    main()
