# Application de Gestion d'Étudiants (POO)

**Auteur :** Lidouma Lidouma Josué Dalcy  
**Formation :** L2 GDA (Gestion Data) — ISI Dakar  
**Évaluation :** TP Noté (Formateur : M. HAMANE)  
**Année Académique :** 2025-2026  

---

## Présentation du Projet
Ce projet est une application console interactive développée en Python. Elle applique les concepts fondamentaux de la Programmation Orientée Objet (POO) vus en cours, notamment :
- L'instanciation et la manipulation d'objets dans des collections (listes).
- L'encapsulation des données via l'utilisation d'attributs privés (`__age`) et de méthodes d'accès (getters/setters).
- L'usage de variables de classe (`nb_etudiants`) faisant office de compteurs dynamiques.

## Fonctionnalités de l'Application
Le menu principal offre les options suivantes :
1. **Lister les étudiants** : Affiche l'ensemble des fiches d'étudiants (Nom et Âge).
2. **Saluer un étudiant** : Déclenche un message de salutation personnalisé.
3. **Modifier l'âge** : Permet de mettre à jour l'âge d'un étudiant de manière sécurisée.
4. **Ajouter un étudiant** : Crée un nouvel objet et incrémente le compteur global.
5. **Supprimer un étudiant** : Retire un profil de la liste et réajuste le compteur.
6. **Afficher le compteur** : Donne en temps réel le nombre total d'étudiants enregistrés.

## Comment lancer le programme

Assurez-vous d'avoir Python 3 installé sur votre système. Ouvrez un terminal dans le dossier du projet et exécutez la commande suivante :

```bash
python tp_etudiants.py


QUESTIONS  /  REPONSES

Partie 1 — Réponses aux questions théoriques

Tu peux inclure ces réponses directement dans ton rapport TP_Gestion_Etudiants.md ou au début de ton code sous forme de commentaires.

    Quel est le rôle de __age ?
    Il s'agit d'un attribut d'instance privé (indiqué par le double underscore __). Son rôle est de stocker l'âge de l'étudiant de manière sécurisée en appliquant le principe d'encapsulation, empêchant sa modification ou son accès direct depuis l'extérieur de la classe.

    Pourquoi utilise-t-on get_age() et set_age() ?
    Ce sont des accesseurs (getter) et mutateurs (setter). On les utilise pour lire (get_age) et modifier (set_age) la valeur de l'attribut privé __age de manière contrôlée, sans casser l'encapsulation.

    Que représente nb_etudiants ?
    C'est un attribut de classe (ou variable statique). Contrairement aux attributs d'instance, il est partagé par toutes les instances de la classe et sert ici de compteur global pour suivre le nombre total d'étudiants créés.

    Quelle est la différence entre nom, _genre et __age ?
    Ils illustrent les trois niveaux de visibilité en Python :

       . nom (Public) : Accessible et modifiable directement depuis n'importe où.

       . _genre (Protégé) : Par convention, indique qu'il ne doit être accessible que dans la classe et ses sous-classes (visibilité restreinte).

       . __age (Privé) : Strictement inaccessible directement de l'extérieur en raison du name mangling de Python.
